
const toggle=document.querySelector('.nav-toggle'),nav=document.querySelector('.nav');
if(toggle&&nav)toggle.addEventListener('click',()=>nav.classList.toggle('show'));
document.querySelectorAll('.enquiry-form').forEach(form=>form.addEventListener('submit',e=>{
 e.preventDefault();
 const data=new FormData(form);
 const vals=[...data.values()].filter(Boolean).join(' | ');
 const msg='Hello, I would like to enquire. '+vals;
 window.open('https://wa.me/919166390767?text='+encodeURIComponent(msg),'_blank','noopener');
}));
