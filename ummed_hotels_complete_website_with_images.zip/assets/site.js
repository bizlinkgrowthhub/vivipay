
const navToggle=document.querySelector('.nav-toggle'),nav=document.querySelector('.nav');
if(navToggle&&nav)navToggle.addEventListener('click',()=>nav.classList.toggle('show'));
const book=document.getElementById('book-demo');
if(book)book.addEventListener('click',()=>{
 const ci=document.getElementById('checkin').value,co=document.getElementById('checkout').value;
 const dest=document.getElementById('destination').selectedOptions[0].textContent;
 const guests=document.getElementById('guests').value;
 if(ci&&co&&new Date(co)<=new Date(ci)){alert('Check-out should be after check-in.');return;}
 const msg='Hello, I want to enquire about booking a stay. Destination: '+dest+'. Check-in: '+(ci||'Not selected')+'. Check-out: '+(co||'Not selected')+'. Guests: '+guests+'. Please share availability and rates.';
 window.open('https://wa.me/919166390767?text='+encodeURIComponent(msg),'_blank','noopener');
});
const now=new Date(),today=new Date(now.getTime()-now.getTimezoneOffset()*60000).toISOString().slice(0,10);
const tomorrow=new Date(now.getTime()+86400000-now.getTimezoneOffset()*60000).toISOString().slice(0,10);
const ci=document.getElementById('checkin'),co=document.getElementById('checkout');
if(ci&&co){ci.min=today;ci.value=today;co.min=tomorrow;co.value=tomorrow;ci.addEventListener('change',()=>{
 const d=new Date(ci.value+'T12:00:00');d.setDate(d.getDate()+1);const min=d.toISOString().slice(0,10);co.min=min;if(co.value<min)co.value=min;
});}
